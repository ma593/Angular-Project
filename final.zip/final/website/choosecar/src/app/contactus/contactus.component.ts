import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'
import { ApiService } from '../api.service'

@Component({
  selector: 'app-contactus',
  templateUrl: './contactus.component.html',
  styleUrls: ['./contactus.component.css']
})
export class ContactusComponent implements OnInit {
  name:string;
  email:string;
  msg:string;
  errmsg:string;
  constructor(private api: ApiService, private router:Router) {
    this.name="";
    this.email="";
    this.msg="";
    this.errmsg="";
   }

  ngOnInit(): void {
  }
  sendreq(name:string,email:string,msg:string)
  {
    var isemail=false;
    this.name=name;
    this.email=email;
    this.msg=msg;
    for(var i =0;i<email.length;i++)
    {
      if(email.charAt(i)=='@')
      {
      isemail=true;
      }
  }
  if(this.name==""||this.email==""||this.msg=="")
  {
    this.errmsg="אחד הנתונים חסר"
  }
  else
  if(isemail==false)
  {
    this.errmsg="אימייל אינו תקין"
  }
  else
  this.errmsg="";
  this.api.contact(this.name,this.email,this.msg).subscribe(({status,message})=>{
  if(status=="ok")
  {
   // this.errmsg="ok";
   alert('ההפניה נשלחה בהצלחה');
  }
  else
  {
    //this.errmsg=message;
    alert('נא לנסות שוב ההפניה לא נשלחה');
  }
  })
  }


}