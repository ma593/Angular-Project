import { Variable } from '@angular/compiler/src/render3/r3_ast';
import { Component, OnInit } from '@angular/core';



import { ApiService } from '../api.service';
interface car{
  id_user:string;
  manufacturer:string;
  model:string;
  year:string;
  price:string;
  col:string;
  engine:string;
  km:string;
  hand:string;
  phone_num:string;

}

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

errmsg:string;
cars:Array<car>=[];
blob:Blob;
reader:ReadableStream;
value:string;

  constructor(private api:ApiService) {
  
    this.errmsg="";
    //this.cars=new Array;
    this.blob=new Blob;
    this.reader=new ReadableStream;
    this.value="";
    
    
   }

  ngOnInit(): void {
   //if(this.bool==false)
   this.search("");
  
   length=0;
    

 //  alert(this.value);
  }
 checksearch(value:string)
 {
   //if(value!="")
  // this.bool=true;
  // this.value=value;
 //  this.search(this.value);
 }
 

search(thedata:string)
{

  this.api.search(thedata).subscribe(({ status, message,data}) => {
  //if(status=="ok")
 // {
    
    for(var j=0;j<length;j++)
    {
      this.cars.pop();
    }
   for(var i=0;i<data.length;i++)
 // this.cars.push(data[i]);
 this.cars[i]=data[i];
 length=i;
 
    
    
 // }
 // else
 // {
 //  this.errmsg=message;

  //}  
    });

  }

}

