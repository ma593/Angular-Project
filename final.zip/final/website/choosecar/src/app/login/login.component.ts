import { stringify } from '@angular/compiler/src/util';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from '../api.service';
import { AppComponent } from '../app.component';
import { RegisterComponent } from '../register/register.component';
import { SearchComponent } from '../search/search.component';

//import {AppComponent} from ''

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  email:string;
  password:string;
  
  errmsg:string;
  constructor(private api: ApiService, private router:Router,private app:AppComponent) { 
  this.email="";
  this.password="";
  this.errmsg="";
  }

  ngOnInit(): void {
  }
checklogin(email:string,password:string)
{
this.email=email;
this.password=password;
if(this.email==""||this.password=="")
{
  this.errmsg="אחד הנתונים חסר";

}
else
{
  this.errmsg="";
  this.api.login(this.email,this.password).subscribe(({ status, message}) => {
    if(status=="ok")
    {
      this.app.user_id=this.email;
     // this.errmsg="ok";
     alert('שלום ברוך הבא');
      //this.app.checklogout(this.errmsg);
      this.api.checklogin("1").subscribe(({status,message})=>{
       
        
    
      })
      this.app.ngOnInit();
     
      //this.app.checklogout(this.errmsg);
    
      this.app.refresh=true;
      this.router.navigate(['search']);
    }
    else{
      //this.errmsg="error";
      alert('שם משתמש לא נמצא במערכת');
    }
  })
}
}
}
