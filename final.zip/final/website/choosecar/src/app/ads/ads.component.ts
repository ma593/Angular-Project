import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'
import { ApiService } from '../api.service'
import { AppComponent } from '../app.component';
import { LoginComponent } from '../login/login.component';
import { SearchComponent } from '../search/search.component';
@Component({
  selector: 'app-ads',
  templateUrl: './ads.component.html',
  styleUrls: ['./ads.component.css']
})
export class AdsComponent implements OnInit {
  id_user:string;
  manufacturer:string;
  model:string;
  year:string;
  price:string;
  col:string;
  engine:string;
  km:string;
  hand:string;
  phone_num:string;
  errmsg:string;
  constructor(private api:ApiService,private app:AppComponent) {
    this.id_user="";
    this.manufacturer="";
    this.model="";
    this.year="";
    this.price="";
    this.col="";
    this.engine="";
    this.km="";
    this.hand="";
    this.phone_num="";
    this.errmsg=""
   }

  ngOnInit(): void {
  }
  ads(manufacturer:string,model:string,year:string,price:string,phone_num:string,engine:string,color:string,km:string,hand:string)
  {
      this.id_user=this.app.user_id;
      this.manufacturer=manufacturer;
      this.model=model;
      this.year=year;
      this.price=price;
      this.col=color;
      this.engine=engine;
      this.km=km;
      this.hand=hand;
      this.phone_num=phone_num;
      if(this.manufacturer==""||this.model==""||this.phone_num==""||this.phone_num.length<1||this.phone_num.length>10)
      alert('נא למלא שדה חובה')
      else
      {
   //   alert(this.id_user+" "+this.manufacturer+" "+this.model+" "+this.price+this.color+" "+this.engine+" "+this.km+" "+this.hand+" "+phone_num)
      this.api.ads(this.id_user,this.manufacturer,this.model,this.year,this.price,this.phone_num,this.engine,this.col,this.km,this.hand).subscribe(({ status, message}) => {
        if(status == "ok")
        {
          // redirect home
          //this.router.navigate(['home']);
          //this.errmsg="OK";
          alert("המודעה נשמרה בהצלחה");
        }
        else
        {
          //this.errmsg=message;
          alert('לא ניתן להוסיף את ההודעה ');
        }
      })
  }
}

  }



