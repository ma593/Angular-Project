import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AppComponent } from './app.component';


interface get_user_data{
  status: "ok" | "error";
  message:string;
  data:Array< user_data>;
}

interface user_data{
  email:string;
  fname:string;
  lname:string;
  address:string;
  phone_num:string;
  password:string;
  is_login:string;
}
interface response{
  status:string;
  message:string;
}

interface search_results{
  status: "ok" | "error";
  message: string;
  data: Array<car>
}

interface car{
  id_user:string;
  manufacturer:string;
  model:string;
  year:string;
  price:string;
  col:string;
  engine:string;
  km:string;
  hand:string;
  phone_num:string;

}

@Injectable({
  providedIn: 'root'
})

export class ApiService {
  private urlAPI:string;

  constructor(private http: HttpClient, private router: Router) {
    this.urlAPI = 'http://localhost:3000/api/';
  }

  // Server API
  checklogin(is_login:string)
  {
    return this.http.post<response>(this.urlAPI + 'checklogin', { 
      is_login,
      
    })
  }
  login(email:string, password:string) {
    return this.http.post<response>(this.urlAPI + 'login', { 
      email,
      password
    })
  }

  signup(email:string, fname:string, lname:string, address:string, phone_num:string, password:string) {
    return this.http.post<response>(this.urlAPI + 'signup', { 
      email,
      fname,
      lname,
      address,
      phone_num,
      password
    })
  }
  contact(name:string,email:string,msg:string)
  {
    return this.http.post<response>(this.urlAPI + 'contact', { 
      name,
      email,
      msg
    })
  }
ads(id_user:string,manufacturer:string,model:string,year:string,price:string,phone_num:string,engine:string,col:string,km:string,hand:string)
{
  return this.http.post<response>(this.urlAPI+'addAds',{
    id_user,manufacturer,model,year,price,phone_num,engine,col,km,hand
  })
}
  
  search(search:string)
  {
    return this.http.post<search_results>(this.urlAPI + 'searchall', { 
      search
    })
  }
  
  getUserDetails(is_login:string) {
    return this.http.post<get_user_data>(this.urlAPI + 'get_user', {
      is_login
    })
  }
  

  setUserDetails(email:string, fname:string, lname:string, address:string, phone_num:string, password:string) {
    return this.http.post<get_user_data>(this.urlAPI + 'set_user_data', {
      email,
      fname,
      lname,
      address,
      phone_num,
      password

    })
  }
  

  
  
  
  
  
 

 
 
}


