import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ContactusComponent } from './contactus/contactus.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { FormsModule } from '@angular/forms';
import { SearchComponent } from './search/search.component';
import { LogoutComponent } from './logout/logout.component';
import { AdsComponent } from './ads/ads.component';



@NgModule({
  declarations: [
    AppComponent,
    ContactusComponent,
    LoginComponent,
    RegisterComponent,
    SearchComponent,
    LogoutComponent,
    AdsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
