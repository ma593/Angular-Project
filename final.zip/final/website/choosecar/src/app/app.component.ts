import { isGeneratedFile } from '@angular/compiler/src/aot/util';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

import { ApiService } from './api.service';
import { LoginComponent } from './login/login.component';
interface user_data{
  email:string;
  fname:string;
  lname:string;
  address:string;
  phone_num:string;
  password:string;
  is_login:string;
}
interface data{
  id:string;
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent  {
  title = 'choosecar';
  errmsg="";
  user_id="";

  //Usr:user[];
  refresh=false;
  
constructor(private api:ApiService,private router:Router)
{
// this.logout();
}
ngOnInit(): void {
  this.logout();
  this.router.navigate(['search']);
}

 checklogout()
 {
  
 }
 getemail(userid:string)
 {
   
   
 }
 logout()
 {
   
 // this.Usr[0].u=this.user_id;
 this.api.getUserDetails("1").subscribe(({ status, message,data}) => {

  this.user_id=data[0].email;
  if(status=="ok")
  {
  //  alert(this.user_id);
 this.refresh=true;
  }
  else
 {
 // alert(this.user_id);
this.refresh=false;
   
  }
 } )

return this.refresh;
}

/*
 checklogin(errmsg:string)
 {
  
  

 }
 */
 /*
 login()
 {
  
return this.checklogin(this.errmsg);
   
 }
 */

 run()
{
  
  this.errmsg="the connection end";
  this.user_id="";
  this.refresh=false;
  //alert("יציאה ממערכת");
  
  this.api.checklogin("0").subscribe(({ status, message}) => {
    if(status=="ok")
    {
      alert("יציאה ממערכת")
    }
    else{
      alert(message);
    }
  })
  
  
}

} 
