import { Component, NgModule, OnInit } from '@angular/core';
import { Router } from '@angular/router'
import { ApiService } from '../api.service'
import { AppComponent } from '../app.component';
import { LoginComponent } from '../login/login.component';
import { SearchComponent } from '../search/search.component';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  email:string;
  fname:string;
  lname:string;
  address:string;
  phone_num:string;
  password:string;
  rpassword:string;
  errmsg:string;



  constructor(private api: ApiService, private router:Router) {
    this.email="";
    this.lname ="";
    this.fname="";
    this.address="";
    this.phone_num="";
    this.password="";
    this.rpassword="";
    this.errmsg="";
   
   }

  ngOnInit(): void {
  
  }

  register(email:string,fname:string,lname:string,address:string,phone_num:string,password:string,rpassword:string){
    this.email=email;
    this.lname=lname;
    this.fname=fname;
    this.address=address;
    this.phone_num=phone_num;
    this.password=password;
    this.rpassword=rpassword;
    var isemail=false;
    var isphone=false;
    
    
    
  //alert(email);
  for(var i =0;i<email.length;i++)
  {
    if(email.charAt(i)=='@')
    {
    isemail=true;
    }
    if(phone_num!=""&&phone_num.charAt(i)>='0'&&phone_num.charAt(i)<='9')
    {
      isphone=true;
    }
  }
  if(this.email==""||this.fname==""||this.lname==""||this.address==""||this.phone_num==""||this.password==""||this.rpassword=="")
  {
    this.errmsg="אחד הנתונים חסר";
    
  }
  else
  if(this.password!=this.rpassword)
  {
    this.errmsg="שני הסיסמאות אינם זהים"
  }
  else
  if(isemail==false&&this.email!="")
  {
    this.errmsg="האיימיל אינו תקין";
  }
else
if(isphone==false&&phone_num!="")
{
    this.errmsg="מספר טלפון אינו תקין"
}
  else
  if(isphone)
  {
    if(this.phone_num.length<10&&this.phone_num.length>1)
    {
      this.errmsg="מספר טלפון אינו תקין"
    }
    else
    {
      this.errmsg="";
      
      this.api.signup(email, fname, lname, address, phone_num, password).subscribe(({ status, message}) => {
        if(status == "ok")
        {
          // redirect home
          alert("נרשמת בהצלחה");
          this.router.navigate(['login']);
         
        }
        else
        {
          this.errmsg=message;
        }
      })
    }
  }
  
    
  }
  
}