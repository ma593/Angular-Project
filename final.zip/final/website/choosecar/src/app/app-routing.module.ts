import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { ContactusComponent } from './contactus/contactus.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HttpClientModule } from '@angular/common/http';
import { SearchComponent } from './search/search.component';
import { LogoutComponent } from './logout/logout.component';
import { AdsComponent } from './ads/ads.component';

const routes: Routes = [{path:'login',component:LoginComponent},
{path:'register',component:RegisterComponent},
{ path:'contactus',component:ContactusComponent},
  {path:'search',component:SearchComponent},
  {path:'logout',component:LogoutComponent},
  {path:'ads',component:AdsComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes), HttpClientModule],
  exports: [RouterModule],
  bootstrap: [AppComponent]
})
export class AppRoutingModule { }
