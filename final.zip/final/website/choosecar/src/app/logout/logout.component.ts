import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginComponent } from '../login/login.component';
import { stringify } from '@angular/compiler/src/util';

import { ApiService } from '../api.service';
import { AppComponent } from '../app.component';
import { RegisterComponent } from '../register/register.component';
import { SearchComponent } from '../search/search.component';
@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {
 
  constructor( ) { 
   
  }
  


  ngOnInit(): void {
 
  }

}
